﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Movies.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string name { get; set; }
        public DateTime releaseDate { get; set; }
        public string director { get; set; }
        public string email { get; set; }
        public string language { get; set; }

        public Category category { get; set; }
    
    }
}
